readme.md
This file should not be translated.
diff between version 3.3 (<) and version 3.4 (>)
9,10c9,10
< 	* Minimum required NVDA version:  2024.1
< 	* Last NVDA version tested:  2025.1
---
> 	* Minimum required NVDA version:  2025.1
> 	* Last NVDA version tested:  2026.1
33c33
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.3.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.4.nvda-addon
